/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Routes, Route, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import styles from './App.module.css'
import { getIngredients } from '../../redux/actions/ingredientsActions';
import { Header } from '../Header/Header';
import { BurgerConstructor } from '../BurgerConstructor/BurgerConstructor';
import { BurgerIngredients } from '../BurgerIngredients/BurgerIngredients';
import { Modal } from '../Modal/Modal';
import { Error } from '../Error/Error';
import { Login } from '../Login/Login';
import { ForgotPassword } from '../ForgotPassword/ForgotPassword';
import { ResetPassword } from '../ResetPassword/ResetPassword';
import { Profile } from '../Profile/Profile';
import { NotFound404 } from '../NotFound404/NotFound404';
import { IngredientDetails } from '../IngredientDetails/IndgredientDetails';
import { Registration } from '../Registration/Registration';

function App() {
  const dispatch = useDispatch();
  let navigate = useNavigate();
  let location = useLocation();
  const { isError, errorMessage, isSuccess } = useSelector((store) => store.ingredients);
  let background = location.state && location.state.background;

  useEffect(() => {
    dispatch(getIngredients())
  }, [])

  return (
    <>
      <Routes location={background || location} >

        <Route path='/*' element={
          <>
            <main className={styles.main}>
              <Header />
              <Outlet />

              {isError &&
                <Modal title="" closeIcon={false} >
                  <Error errorMessage={errorMessage} />
                </Modal>
              }
            </main>
          </>
        }>

          <Route index element={
            <>
              {isSuccess &&
                <DndProvider backend={HTML5Backend} >
                  <section className={styles.section_content}>
                    <BurgerIngredients />
                    <BurgerConstructor />
                  </section>
                </DndProvider>
              }
            </>
          } />

          <Route path='login' element={<Login />} />
          <Route path='forgot-password' element={<ForgotPassword />} />
          <Route path='reset-password' element={<ResetPassword />} />
          <Route path='profile' element={<Profile />} />
          <Route path='registration' element={<Registration />} />
          <Route path='ingredients/:id' element={isSuccess && <IngredientDetails />} />
          <Route path='*' element={<NotFound404 />} />
        </Route>
      </Routes>

      {background &&
        <>
          <Routes>
            <Route path='/*' element={<Header />} />

            {isSuccess && (
              <Route
                path='ingredients/:id'
                element={
                  <>
                    <Modal
                      title="Детали ингредиента"
                      onClose={() => navigate(-1)}
                      closeIcon={false}
                    >
                      <IngredientDetails />
                    </Modal>
                  </>
                } />
            )}

            {isError &&
              <Modal title="" closeIcon={false} >
                <Error errorMessage={errorMessage} />
              </Modal>
            }

            <Route path='*' element={<NotFound404 />} />
          </Routes>
        </>
      }
    </>
  );
}

export default App;
