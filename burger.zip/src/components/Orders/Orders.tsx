import styles from './Orders.module.css'

export function Orders() {

  return (
    <h1>Orders</h1>
  )
}
