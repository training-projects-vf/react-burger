import styles from './Overlay.module.css'

export function ModalOverlay() {

  return (
    <div id="overlay" className={styles.overlay} />
  )
}
