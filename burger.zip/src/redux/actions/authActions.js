import { authReg } from "../../utils/auth";

export const REG_REQUEST_SUBMIT = 'REG_REQUEST';
export const REG_REQUEST_SUCCESS = 'REG_REQUEST_SUCCESS';

export function register(regData) {
  console.log('regData in register', regData)
  return function (dispatch) {
    dispatch({ type: REG_REQUEST_SUBMIT })

    authReg(regData)
      .then((regResponse) => {
        console.log('authReg response', regResponse)
        dispatch({ type: REG_REQUEST_SUCCESS })
      })
      .catch((err) => console.log('err in authReg', err))
  }
}
