import {
  INGREDIENTS_REQUEST,
  INGREDIENTS_REQUEST_SUCCESS,
  INGREDIENTS_REQUEST_FAILED,
} from "../actions/appActions"

const initialState = {
  ingredientsRequest: false,
  ingredientsRequestSuccess: false,
  ingredientsRequestFailed: false,
  isError: false,
  errorMessage: null,
  ingredients: [],
}

export const appReducer = (state = initialState, action) => {
  switch (action.type) {

    default: {
      console.log('default');
      return {
        ...state,
        isError: true,
        errorMessage: 'Какой-то непонятный запрос пришел. Будем разбираться. '
      }
    }

    case INGREDIENTS_REQUEST: {
      console.log('request')
      return ({
        ...state,
        ingredientsRequest: true,
        isError: false,
        errorMessage: null,
      })
    }

    case INGREDIENTS_REQUEST_SUCCESS: {
      console.log('success', action.ingredients)
      return ({
        ...state,
        ingredientsRequest: false,
        ingredientsRequestSuccess: true,
        isError: false,
        errorMessage: null,
        ingredients: action.ingredients,
      })
    }

    case INGREDIENTS_REQUEST_FAILED: {
      console.log('request_failed', state)
      return ({
        ...state,
        ingredientsRequest: false,
        isError: true,
        errorMessage: `Сбой в галактической квантовой сети...\nПовторите заказ позже.`
      })
    }

  }
}
