/* eslint-disable default-case */
import {
  REG_REQUEST_SUBMIT,
  REG_REQUEST_SUCCESS
} from "../actions/authActions";

const initialState = {
  regRequest: false,
  isRegSuccess: false,
}

export const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case REG_REQUEST_SUBMIT: {
      return ({
        ...state,
        isRegSuccess: false,
        regRequest: true,
      })
    }

    case REG_REQUEST_SUCCESS: {
      return ({
        ...state,
        isRegSuccess: true,
        regRequest: false,
      })
    }
  }
}
