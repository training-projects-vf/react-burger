export const config = {
  ingredientsURL: 'https://norma.nomoreparties.space/api/ingredients',
  orderURL: 'https://norma.nomoreparties.space/api/orders',
}
