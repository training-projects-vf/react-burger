export const config = {
  dataURL: 'https://norma.nomoreparties.space/api/ingredients',
}
