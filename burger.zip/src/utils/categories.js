export const categories = [
  {
    categoryMarker: 'bun',
    ruCategoryName: 'Булки',
  },
  {
    categoryMarker: 'sauce',
    ruCategoryName: 'Соусы',
  },
  {
    categoryMarker: 'main',
    ruCategoryName: 'Начинки',
  }
]
