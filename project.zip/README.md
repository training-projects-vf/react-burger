Training project on Yandex.Practicum React course
