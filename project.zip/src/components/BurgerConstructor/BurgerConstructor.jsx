import React from 'react';
import PropTypes from 'prop-types';
import styles from './BurgerConstructor.module.css'
import { ingredients } from '../../utils/data';
// import { BurgerComponent } from '../BurgerComponent/BurgerComponent'
import {
  Button,
  ConstructorElement,
  DragIcon,
  CurrencyIcon
} from '@ya.praktikum/react-developer-burger-ui-components';


class BurgerIngredients extends React.Component {

  render() {
    return (
      <>

        <section className={styles.section}>
          <div className={styles.container_first_last}>
            <ConstructorElement type="top"
              isLocked={true}
              text="Краторная булка N-200i (верх)"
              price={200}
              thumbnail={ingredients[0].image}
              key={'top'}
            />
          </div>

          <div className={`${styles.section_list} custom-scroll`}>
            {ingredients.map((item) => {
              return (
                <div className={styles.container}>
                  <DragIcon />
                  <ConstructorElement
                    text={item.name}
                    price={item.price}
                    thumbnail={item.image}
                    key={item.id}
                  />
                </div>
              )
            })}
          </div>

          <div className={styles.container_first_last}>
            <ConstructorElement
              type="bottom"
              isLocked={true}
              text="Краторная булка N-200i (низ)"
              price={200}
              thumbnail={ingredients[0].image}
            />
          </div>

          <div className={styles.container_price}>
            <p className="text text_type_digits-medium">
              610
              <CurrencyIcon type="primary" />
            </p>
            <Button type="primary" size="large">Оформить заказ</Button>
          </div>
        </section>
      </>
    )
  }
}

BurgerIngredients.propTypes = {
  some: PropTypes.number,
}

export default BurgerIngredients
