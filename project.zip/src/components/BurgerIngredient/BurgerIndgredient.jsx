import { CurrencyIcon, DeleteIcon, DragIcon } from "@ya.praktikum/react-developer-burger-ui-components";
import React from "react";
import styles from './BurgerIngredient.module.css';

export class BurgerComponent extends React.Component {

  render() {
    const { name, price, image: image_mobile } = this.props.component;
    return (
      <div className={styles.container}>
        <DragIcon type='primary' />
        <img className={styles.illustration} src={image_mobile} alt='burger component' />
        <div className={styles.ingredient}>
          <p className={`text text_type_main-default ${styles.name}`}>{name}</p>
          <div className={styles.price}>
            <p className="text text_type_digits-default">{price}</p>
            <CurrencyIcon type='primary' />
          </div>
          <DeleteIcon type='primary' />

        </div>

      </div>
    )
  }
}
