import React from 'react';
import PropTypes from 'prop-types';
import styles from './BurgerIngredients.module.css'
import { Tab } from '@ya.praktikum/react-developer-burger-ui-components';
import { categories } from '../../utils/categories.js';
import { IngredientsCategory } from '../IngredientsCategory/IngredientsCategory.jsx'

function BurgerIngredients() {
  const [current, setCurrent] = React.useState('one')

  return (
    <section className={styles.section}>
      <p className="text text_type_main-large">Соберите бургер</p>

      <div style={{ display: 'flex' }}>
        <Tab value="one" active={current === 'one'} onClick={setCurrent}>
          Булки
        </Tab>
        <Tab value="two" active={current === 'two'} onClick={setCurrent}>
          Coусы
        </Tab>
        <Tab value="three" active={current === 'three'} onClick={setCurrent}>
          Начинки
        </Tab>
      </div>

      {
        categories.map((item, index) => {
          return <IngredientsCategory key={index} category={item} />
        })
      }

    </section>
  )

}

BurgerIngredients.propTypes = {
  some: PropTypes.number,
}

export default BurgerIngredients
