import React from "react";
import { ingredients } from '../../utils/data.js';

export function IngredientsCategory(props) {
  const { categoryMarker, ruCategoryName } = props.category;
  const categoryIngredientsList = ingredients.filter(item => item.type === categoryMarker)

  return (
    <div>
      <p className="text text__type_medium">{ruCategoryName}</p>
      {
        categoryIngredientsList.map((item) => {
          return <p key={item._id}>{item.name}</p>
        })
      }
    </div>
  )
}
